/* automatic mobile overrides */
/* handheld */
var vpSize = AUI.u.getVPSize();
if(Math.min(vpSize.width,vpSize.height) < 500){
	A5.overrides.add('editCombo',{
		base: {
			decouple: true,
			window: {
				width: '100%',
				height: '50%',
				pointer: {show: false},
				location: ['dock','bottom'],
				animation: {
					show: {type: 'css-slide'}
				}
			},
			selectionRequired: true
		}
	});
	A5.overrides.add('editTree',{
		base: {
			decouple: true,
			window: {
				width: '100%',
				height: '50%',
				pointer: {show: false},
				location: ['dock','bottom'],
				animation: {
					show: {type: 'css-slide'}
				}
			},
			selectionRequired: true
		}
	});
	A5.overrides.add('editDateTime',{
		base: {
			decouple: true,
			window: {
				width: '100%',
				pointer: {show: false},
				location: ['dock','bottom'],
				animation: {
					show: {type: 'css-slide'}
				}
			},
			dateTime: {
				timePicker: {
					edit: { menu: { hourColumns: 6}},
					selectionRequired: true
				},
				combinedContainer: { className: 'iOSEditDateTimeCont'}
			},
			selectionRequired: true
		}
	});
} else if(A5.flags.supportsTouch){
	A5.overrides.add('editCombo',{
		base: {
			decouple: true,
			selectionRequired: true
		}
	});
	A5.overrides.add('editTree',{
		base: {
			decouple: true,
			selectionRequired: true
		}
	});
	A5.overrides.add('editDateTime',{
		base: {
			decouple: true,
			dateTime: { timePicker: { selectionRequired: true}},
			selectionRequired: true
		}
	});
}