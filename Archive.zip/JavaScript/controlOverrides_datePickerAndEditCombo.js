
function __a5ControlBehaviorOverrides() {

	/*
	if the width of the viewport is less than 500px make datePickers and edit-combos
	pop up from the bottom of the screen, centered horizontally
	*/
	var vpSize = AUI.u.getVPSize();
	alert($u.o.toJSON(vpSize));
	if(Math.min(vpSize.width,vpSize.height) < 500){
		A5.overrides.add('editCombo',{
			base: {
				decouple: true,
				window: {
					width: '100%',
					height: '50%',
					pointer: {show: false},
					location: ['dock','bottom'],
					animation: {
						show: {type: 'css-slide'}
					}
				}
			}
		});
		A5.overrides.add('editDateTime',{
			base: {
				decouple: true,
				window: {
					pointer: {show: false},
					location: ['dock','bottom'],
					animation: {
						show: {type: 'css-slide'}
					}
				},
				dateTime: {
					combinedContainer: {
						className: 'centerTable'
					},
					timePicker: {
						selectionRequired: true,
						edit: { menu: { hourColumns: 6}}
					}
				}
			}
		});
	}

}

__a5ControlBehaviorOverrides()